#!/usr/bin/env bash
#===============================================================================
# build-ngspice-wasm.sh – Build ngspice as WebAssembly
#===============================================================================
set -euo pipefail

# ---------------------------- Configuration -----------------------------------
NGSPICE_REPO="https://git.code.sf.net/p/ngspice/ngspice"
NGSPICE_TAG="ngspice-46"
WORK_DIR="$PWD/dist"
NGSPICE_SRC="$WORK_DIR/ngspice"
BUILD_DIR="$NGSPICE_SRC/build"
OUT_DIR="$PWD"

# ---------------------------- Utility functions -------------------------------
info() { echo -e "\e[1;32m[INFO]\e[0m  $*"; }
warn() { echo -e "\e[1;33m[WARN]\e[0m  $*"; }
err() {
  echo -e "\e[1;31m[ERROR]\e[0m $*" >&2
  exit 1
}

usage() {
  sed -n '2,/^$/ s/^# //p' "$0"
  exit 0
}

clean_build() {
  info "Cleaning previous build…"
  rm -rf "$WORK_DIR"
  info "Clean complete."
  exit 0
}

# ---------------------------- Check prerequisites -----------------------------
check_prerequisites() {
  info "Checking required tools…"
  local missing=()
  for cmd in git sed make emcc node python3 npx; do
    command -v "$cmd" >/dev/null || missing+=("$cmd")
  done
  if [ ${#missing[@]} -gt 0 ]; then
    echo "Missing: ${missing[*]}"
    err "Please install missing tools (see script header)."
  fi
  info "All tools found."
}

# ---------------------------- Clone source ------------------------------------
clone_source() {
  mkdir -p "$WORK_DIR"
  if [ ! -d "$NGSPICE_SRC" ]; then
    info "Cloning ngspice (tag $NGSPICE_TAG)…"
    git clone --branch "$NGSPICE_TAG" --depth 1 "$NGSPICE_REPO" "$NGSPICE_SRC"
  else
    info "Source already exists – skipping clone."
  fi
}

# ---------------------------- Patch source ------------------------------------
patch_source() {
  info "Patching source for WASM compatibility & stability…"

  # 1. Fix compiler warnings that break strict builds
  sed -i 's/-Wno-unused-but-set-variable/-Wno-unused-const-variable/g' "$NGSPICE_SRC/configure.ac"

  # 2. Remove POSIX getrusage check (unsupported in WASM)
  sed -i 's/AC_CHECK_FUNCS(\[time getrusage\])/AC_CHECK_FUNCS(\[time\])/g' "$NGSPICE_SRC/configure.ac"

  # 3. Fix function signature mismatch (emscripten strict typing)
  sed -i 's/sh_vecinit(void/sh_vecinit(int/' "$NGSPICE_SRC/src/frontend/outitf.c" || true

  # 4. DISABLE DLOPEN (WASM cannot load .so plugins at runtime)
  sed -i 's/#ifdef HAVE_DLFCN_H/#if 0 \/\/ DISABLED FOR WASM/' "$NGSPICE_SRC/src/main.c" 2>/dev/null || true
  sed -i 's/#include <dlfcn.h>/\/\/ #include <dlfcn.h> \/\/ DISABLED FOR WASM/' "$NGSPICE_SRC/src/spicelib/input/inpcom.c" 2>/dev/null || true

  # 5. STUB SIGNAL HANDLERS (WASM has no POSIX signals)
  if [ -f "$NGSPICE_SRC/src/spicelib/misc/ftsignal.c" ]; then
    sed -i 's/signal(SIGINT, sigint_handler);/\/\/ signal(SIGINT, sigint_handler); \/\/ DISABLED FOR WASM/' "$NGSPICE_SRC/src/spicelib/misc/ftsignal.c"
    sed -i 's/signal(SIGSEGV, sigsegv_handler);/\/\/ signal(SIGSEGV, sigsegv_handler); \/\/ DISABLED FOR WASM/' "$NGSPICE_SRC/src/spicelib/misc/ftsignal.c"
    sed -i 's/signal(SIGTERM, sigterm_handler);/\/\/ signal(SIGTERM, sigterm_handler); \/\/ DISABLED FOR WASM/' "$NGSPICE_SRC/src/spicelib/misc/ftsignal.c"
  fi

  info "All patches applied successfully."
}

# ---------------------------- Run autogen -------------------------------------
run_autogen() {
  info "Running autogen…"
  (cd "$NGSPICE_SRC" && ./autogen.sh)
}

# ---------------------------- Configure build ---------------------------------
configure_build() {
  if [ -d "$BUILD_DIR" ]; then
    warn "Build directory already exists. Run '$0 --clean' first."
    err "Aborting due to existing build directory."
  fi
  mkdir -p "$BUILD_DIR"
  info "Configuring with emconfigure…"

  export CFLAGS="-O3 -DEMSCRIPTEN"
  export LDFLAGS="-O3"
  (cd "$BUILD_DIR" && emconfigure ../configure \
    --host=wasm32-unknown-emscripten \
    --enable-static \
    --disable-shared \
    --with-readline=no \
    --without-x \
    --disable-debug \
    --disable-openmp \
    --disable-xspice \
    --enable-cider \
    --with-klu=yes \
    --with-fftw=yes \
    --with-osdi=no \
    --enable-pthread=no \
    ac_cv_prog_cc_cross=yes \
    ac_cv_func_malloc_0_nonnull=yes \
    ac_cv_func_realloc_0_nonnull=yes)
}

# ---------------------------- Compile library ---------------------------------
compile_library() {
  info "Compiling ngspice & static libraries (emmake)…"
  export CFLAGS="-O3 -DEMSCRIPTEN"
  export LDFLAGS="\
-s SINGLE_FILE=1 \
-s MODULARIZE=1 \
-s ENVIRONMENT='web,node' \
-s ALLOW_MEMORY_GROWTH=1 \
-s INITIAL_MEMORY=256MB \
-s STACK_SIZE=10MB \
-s ERROR_ON_UNDEFINED_SYMBOLS=0 \
-s SUPPORT_LONGJMP='emscripten' \
-s NO_EXIT_RUNTIME=1 \
-s INVOKE_RUN=0 \
-s WASM_BIGINT=1 \
-s ASSERTIONS=0 \
-s EXPORT_ES6=1 \
-s EXPORT_NAME=\"createNgspiceModule\" \
-s EXPORT_ALL=1 \
-O3 \
"
  (cd "$BUILD_DIR" && emmake make LDFLAGS="$LDFLAGS" -j$(nproc))
}

# ---------------------------- Copy & generate .d.ts ---------------------------
finalize_output() {
  info "Copying ngspice.js and generating TypeScript definitions..."
  local JS_SRC=""
  if [ -f "$BUILD_DIR/src/ngspice" ]; then
    JS_SRC="$BUILD_DIR/src/ngspice"
  elif [ -f "$BUILD_DIR/src/ngspice.js" ]; then
    JS_SRC="$BUILD_DIR/src/ngspice.js"
  else
    warn "Could not find compiled ngspice JS in $BUILD_DIR/src/"
    return 1
  fi

  mkdir -p "$OUT_DIR"
  cp "$JS_SRC" "$OUT_DIR/ngspice.js"
  info "Copied to $OUT_DIR/ngspice.js"

  cat >"$OUT_DIR/ngspice.d.ts" <<'TYPESCRIPT_EOF'
/**
 * ngspice WebAssembly Module Interface
 * Auto-generated for Emscripten MODULARIZE=1 + EXPORT_ES6=1 + EXPORT_ALL=1
 */

export interface NgspiceModuleOptions {
  noInitialRun?: boolean;
  stdin?: (() => number | null) | null;
  print?: ((text: string) => void) | null;
  printErr?: ((text: string) => void) | null;
  locateFile?: ((url: string, prefix: string) => string) | null;
  onRuntimeInitialized?: () => void;
  onAbort?: (reason: any) => void;
  [key: string]: any;
}

export interface NgspiceModule {
  // Runtime State & Lifecycle
  calledRun: boolean;
  noInitialRun: boolean;
  noExitRuntime: boolean;
  onRuntimeInitialized?: () => void;
  onAbort?: (reason: any) => void;
  ExitStatus: any;

  // I/O Hooks
  stdin: ((...args: any[]) => any) | null;
  print: ((text: string) => void) | null;
  printErr: ((text: string) => void) | null;
  locateFile: ((url: string, prefix: string) => string) | null;

  // Memory & Typed Arrays  HEAP8: Int8Array;
  HEAP16: Int16Array;
  HEAP32: Int32Array;
  HEAPU8: Uint8Array;
  HEAPU16: Uint16Array;
  HEAPU32: Uint32Array;
  HEAPF32: Float32Array;
  HEAPF64: Float64Array;
  HEAP64: BigInt64Array;
  HEAPU64: BigUint64Array;
  wasmMemory: WebAssembly.Memory;
  _malloc(size: number): number;
  _free(ptr: number): void;
  alignMemory(size: number): number;
  growMemory(size: number): boolean;
  getHeapMax(): number;

  // Stack & Pointer Utilities
  stackSave(): number;
  stackRestore(ptr: number): void;
  stackAlloc(size: number): number;
  getValue(ptr: number, type?: "i8"|"i16"|"i32"|"i64"|"float"|"double"|"*"): number | bigint;
  setValue(ptr: number, value: number | bigint, type?: "i8"|"i16"|"i32"|"i64"|"float"|"double"|"*"): void;
  wasmTable: WebAssembly.Table;
  getWasmTableEntry(idx: number): Function;

  // String Conversion
  UTF8ToString(ptr: number, maxBytesToRead?: number): string;
  UTF8ArrayToString(heap: Uint8Array, idx: number, maxBytesToRead?: number): string;
  lengthBytesUTF8(str: string): number;
  stringToUTF8(str: string, outPtr: number, maxBytesToWrite?: number): void;
  stringToUTF8Array(str: string, heap: Uint8Array, outIdx: number, maxBytesToWrite?: number): number;
  intArrayFromString(str: string): number[];

  // Filesystem & Environment
  FS: any;
  PATH: any;
  TTY: any;
  ENV: Record<string, string>;
  SYSCALLS: any;
  PIPEFS: any;
  MEMFS: any;
  PATH_FS: any;
  getExecutableName: () => string;

  // Runtime Callbacks
  addOnPostRun: (cb: () => void) => void;
  addOnPreRun: (cb: () => void) => void;
  onPostRuns: any[];
  onPreRuns: any[];  callRuntimeCallbacks: (queue: any[]) => void;
  keepRuntimeAlive: () => boolean;
  randomFill: (buf: Uint8Array) => void;
  base64Decode: (str: string) => Uint8Array;

  // Syscall & POSIX Wrappers (typed as number returns for TS safety)
  ___assert_fail: (cond: number, file: number, line: number, func: number) => void;
  ___cxa_throw: (ptr: number, type: number, destructor: number) => void;
  ___syscall_chdir: (path: number) => number;
  ___syscall_fcntl64: (fd: number, cmd: number, varargs: number) => number;
  ___syscall_fstat64: (fd: number, buf: number) => number;
  ___syscall_getcwd: (buf: number, size: number) => number;
  ___syscall_ioctl: (fd: number, req: number, varargs: number) => number;
  ___syscall_lstat64: (path: number, buf: number) => number;
  ___syscall_openat: (dirfd: number, path: number, flags: number, mode: number) => number;
  ___syscall_readlinkat: (dirfd: number, path: number, buf: number, bufsize: number) => number;
  ___syscall_stat64: (path: number, buf: number) => number;
  ___syscall_unlinkat: (dirfd: number, path: number, flags: number) => number;
  _fd_read: (fd: number, iov: number, iovcnt: number, pnum: number) => number;
  _fd_write: (fd: number, iov: number, iovcnt: number, pnum: number) => number;
  _fd_close: (fd: number) => number;
  _fd_seek: (fd: number, low: number, high: number, whence: number, pnew: number) => number;
  _main: (argc: number, argv: number) => number;
  _exit: (status: number) => void;
  _proc_exit: (code: number) => void;

  // Time & Memory Internals
  _emscripten_get_now: () => number;
  _emscripten_date_now: () => number;
  _emscripten_resize_heap: (requested_size: number) => boolean;
  _environ_get: (environ: number, buffer: number) => number;
  _environ_sizes_get: (pargc: number, pbufSize: number) => number;

  // Catch-all for EXPORT_ALL=1 (covers _ngSpice_* APIs and any future C exports)
  [key: string]: any;
}

/**
 * Factory function to instantiate the ngspice WebAssembly module.
 * @param options Configuration options for the module
 * @returns Promise resolving to the initialized NgspiceModule
 */
export default function createNgspiceModule(options?: NgspiceModuleOptions): Promise<NgspiceModule>;
TYPESCRIPT_EOF

  info "Generated TypeScript definitions at $OUT_DIR/ngspice.d.ts"
}

# ---------------------------- Main --------------------------------------------
main() {
  case "${1:-}" in
  --help | -h) usage ;;
  --clean) clean_build ;;
  esac

  check_prerequisites
  clone_source
  patch_source
  run_autogen
  configure_build
  compile_library
  finalize_output

  info "Done."
}

main "$@"
